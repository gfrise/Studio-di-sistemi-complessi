#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "myClibrary.h"

#define PIgreco 3.1415926535897932385


int main(int argc, char* argint[]) {

  int i,j,seed;

  /*printf("Ho ricevuto %d argomenti\n", argc-1);
  printf("Questi argomenti sono:\n");
  
  for(i=1; i<=argc-1; i++)
    printf("%s\n", argint[i]);*/


  FILE *fp0;
  double param[3];
  fp0=fopen("input_parametersOUmom.dat", "r");
  for(i=0; i<3;i++){
     fscanf(fp0,"%lf \n",&param[i]);
  }
  fclose(fp0);

  printf(" \n");
  double gammaOU;
  printf("Valore del parametro gamma \n");
  gammaOU=param[0];
  printf("gamma= %lf \n",gammaOU);
	  
  printf("\n");
  double delt;
  int enne;
  printf("Numero di punti per unita' di tempo \n");
  enne=(int)param[1];
  delt=pow(enne,-1.);
  printf("Il time-step e': %lf \n", delt);
  
  
  printf("\n");
  int nENS;
  printf("Size dell'Ensemble \n");
  nENS=(int)param[2];
  printf("nENS= %d \n",nENS);
  
  printf("\n");
  int nR,staz;
  printf("Numero di punti che vuoi generare \n");
  nR=atoi(argint[1]);
  printf("nR= %d \n",nR);
  staz=1;
  
  printf("\n");
  double x0;
  printf("Starting-point della simulazione \n");
  /*x0=(double)atof(argint[2]);
  printf("x0= %lf \n",x0);*/
  printf("x0= SELEZIONE RANDOM \n");
  

  printf("\n Inizio di tutte le simulazioni: Avvio le iterazioni \n");
  int iter;
  double emme[nENS],emme2[nENS];
  for(iter=0;iter<nENS;iter++){
  
  double *Z1;
  Z1=allocamem1(staz*nR*enne);
  double x1,x2,gam;
  double m=0;
  double s=2*delt;
  seed=19999999+rand()%100000001;

  srand(seed);
  for(i=0; i<staz*nR*enne;i++){
         x1=(float)rand()/(float)RAND_MAX;
	  if(x1>0){
	     x2=(float)rand()/(float)RAND_MAX;
	     gam=sqrt(-2.*log(x1))*sin(2.*PIgreco*x2);
	     Z1[i]=m+(double) sqrt(s)*gam;
	  }
    }

  double *delXs,*Xs;
  delXs=allocamem1(staz*nR*enne);
  Xs=allocamem1(staz*nR*enne);

  Xs[0]=(double)rand()/RAND_MAX;
  Xs[0]=Xs[0]*2.-1.;
  for(i=0; i<staz*nR*enne;i++){
      delXs[i]=-gammaOU*Xs[i-1]*delt+Z1[i];
      Xs[i]=Xs[i-1]+delXs[i];
  }

  double *X;
  int p;
  X=allocamem1(nR);
  for(i=0; i<staz*nR*enne;i++){
     p=(double) i/enne;
     X[p]=Xs[i];
  }

  emme[iter]=mymedia(staz*nR,X);
  
  free(delXs);
  free(Z1);
  free(Xs);
  free(X);

  }
  printf("\n Fine di tutte le simulazioni: Chiudo le iterazioni \n");
  
  double emmeav,emme2av,emme3av,emme4av,emme5av,emme6av;
  emmeav=mymedia(nENS,emme);
  emme2av=mymom2(nENS,emme);
  emme3av=mymom3(nENS,emme);
  emme4av=mymom4(nENS,emme);
  emme5av=mymom5(nENS,emme);
  emme6av=mymom6(nENS,emme);
    
  FILE *fp3;
  fp3=fopen("momenti.dat","w");
  fprintf(fp3,"%d %lf %lf %lf %lf %lf %lf \n", nR, emmeav,emme2av,emme3av,emme4av,emme5av,emme6av);
  fclose(fp3);


}
